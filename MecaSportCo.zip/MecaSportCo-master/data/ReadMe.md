# Uploaded data

GitHub ne permettant pas l'upload de fichier de plus de 25 Mo, les données disponibles dans ce répertoire GitHub correspondent aux 4 quarts temps du match San Antonio Spurs vs. Washington Wizards. On peut retrouver ce match à l'adresse : https://stats.nba.com/game/0021500061/playbyplay/?GameID=0021500061.

